package com.example.low.movierater

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_add_movie.*

class AddMovie : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_movie)
    }




    fun btnAddMovie(v: View){
        if(etReleaseDate == null || etDescription == null || etName == null){

            Toast.makeText(this, "Details Incomplete!",Toast.LENGTH_SHORT).show()

        } else{
            Toast.makeText(this, "Movie Added!",Toast.LENGTH_SHORT).show()
        }
    }



}
